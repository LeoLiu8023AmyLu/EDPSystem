/** Automatically generated file. DO NOT MODIFY */
package com.fragmentdemo8_listfragment;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}