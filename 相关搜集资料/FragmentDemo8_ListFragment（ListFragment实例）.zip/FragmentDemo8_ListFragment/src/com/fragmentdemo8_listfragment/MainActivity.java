package com.fragmentdemo8_listfragment;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
/**
 * ListFragment��һ��ʵ��Demo
 */
public class MainActivity extends Activity {
	private Button button;
	private FragmentManager manager;
	private FragmentTransaction transaction;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		manager = getFragmentManager();
		
		button = (Button) findViewById(R.id.button);
		/**
		 * ���Activity�еĸð�ť��Activity���ڲ����м�����ArticleListFragment������ʾ�б����ݡ�
		 */
		button.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				transaction = manager.beginTransaction();
				ArticleListFragment articleListFragment = new ArticleListFragment();
				transaction.add(R.id.center, articleListFragment, "center");
				transaction.commit();
			}
		});
	}

}
