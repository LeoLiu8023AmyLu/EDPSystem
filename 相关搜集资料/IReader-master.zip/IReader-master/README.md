# IReader
一个简约的本地txt阅读器。

![image](https://github.com/YuanWenHai/IReader/blob/master/screenshots/main.jpg)
![image](https://github.com/YuanWenHai/IReader/blob/master/screenshots/chapters.jpg)
![image](https://github.com/YuanWenHai/IReader/blob/master/screenshots/page.png)
![image](https://github.com/YuanWenHai/IReader/blob/master/screenshots/searcher.png)
![image](https://github.com/YuanWenHai/IReader/blob/master/screenshots/nightMode.png)
