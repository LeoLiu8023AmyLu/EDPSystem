package com.will.ireader.base;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by will on 2016/10/29.
 */

public class BaseActivity extends AppCompatActivity {

}
