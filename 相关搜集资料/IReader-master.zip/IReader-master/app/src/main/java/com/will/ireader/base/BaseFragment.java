package com.will.ireader.base;

import android.app.Fragment;

/**
 * Created by will on 2016/10/29.
 */

public class BaseFragment extends Fragment {
}
